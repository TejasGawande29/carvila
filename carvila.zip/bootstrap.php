<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
     <!-- **********CDN:-contain delivery network -->
      <!-- integrityL:- it Integrate the newest version acrooss server -->
       <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur magnam autem minima dolorum illum, exercitationem rerum deserun  </h1>
       <button class="btn btn-outline-secondary btn-lg"> Submit Now</button>
       
       <input type="text" class="form-control w-100 m-5 p-5" style="border-color: red;">
       
       
       
       
</body>
</html>