<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Addition</title>
</head>
<body>
    <form action="index.php" method="get">
        <input type="text" name="num1">
        <input type="text" name="num2">
        <button>Add</button>
    </form>
</body>
</html>