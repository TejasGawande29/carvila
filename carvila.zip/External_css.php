<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bootstrap</title>
    <link rel="stylesheet" href="/CSS/External.css">
</head>

<body>
   
    <!-- <p>priority of css files depends upon sequence of css files . If External css file is written below internal file then internal css file will execute</p> -->
    <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius dicta adipisci, in itaque quisquam iusto.
        Inventore numquam, delectus nesciunt, minus iusto doloremque vel deserunt doloribus pariatur voluptate, cumque
        nobis soluta!</h1>

</body>

</html>