<footer class="footy">
        <div class="inf">
            <h4>CARVILLA</h4>
            <p>Ased do eiusm tempor incidi ut labore et dolore magnaian aliqua. Ut enim ad minim veniam.</p>
            <p>name@domain.com +1 (222) 1234567890</p>

        </div>
        <div class="inf">
            <h5>ABOUT DEVLOON</h5>
            <ul>
                <li>About Us</li>
                <li>Career</li>
                <li>Terms of service</li>
                <li>Privacy Policy</li>
            </ul>

        </div>
        <div class="inf">
            <h5>TOP BRANDS</h5>
            <ul>
                <li>BMW</li>
                <li>Lamborghini</li>
                <li>Camaro</li>
                <li>Audi</li>
                <li>Infinity</li>
                <li>Nissan</li>
                <li>Ferrari</li>
            </ul>
        </div>
        <div class="inf">
            <h5>NEWS LETTER</h5>
            <P>Subscribe to get latest news update and informations</P>
            <input type="email" placeholder="Add Email">
        </div>
    </footer>
    <div class="copyright">
        <hr style="width: 90vw;">
        <div class="conntained">
            <p>© copyright. Designed and Developed by Tejas.</p>
            <div class="social">
                <a href="www.facebook.com"><img src="img/fblogo.png" alt="" width="20px" height="20px"></a>
                <a href="www.instagram.com"><img src="img/instalogo.png" alt="" width="20px" height="20px"></a>
                <a href="www.twitter.com"><img src="img/twtlogo.png" alt="" width="20px" height="20px"></a>
                <a href="www.youtube.com"><img src="img/ytlogo.webp" alt="" width="20px" height="20px"></a>
            </div>
        </div>
    </div>
