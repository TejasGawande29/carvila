<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>color</title>
</head>
<body>
    <form action="color.php" method="get">
        <input type="text" name="text" placeholder="Enter Your Text!">
        <input type="text" name="color" placeholder="Enter color!">
        <input type="text" name="bg" placeholder="Enter Background Color">
        <button>Apply Properties</button>
    </form>
</body>
</html>