<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <div style="display: flex; ">
        <div style="width: 20%;">
           <?php include_once('layouts/sidebar.php');?>
        </div>
        <div style="width: 80%;">
        <h1>This is Dashboard</h1>
        </div>

    </div>
</body>
</html>