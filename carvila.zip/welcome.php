<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demo</title>
</head>
<body>
    <!-- Interprated Language -->
    <h1>Welcome</h1>
    <h2>welcome</h2>
    <h3>welcome</h3>
    <h4>welcome</h4>
    <h5>welcome</h5>
    <h6>welcome</h6>
    <h7>welcome</h7>
    <h8>welcome</h8>
</body>
</html>